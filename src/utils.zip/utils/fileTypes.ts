export const videoTypes = ['webm', 'mkv', 'ogg', 'ogv', 'avi', 'wmv', 'mp4', 'm4v']

export const audioTypes = ['mp3', 'wav', 'aac', 'amr']